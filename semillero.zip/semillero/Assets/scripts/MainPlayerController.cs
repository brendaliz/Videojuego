﻿using UnityEngine;
using System.Collections;

public class MainPlayerController : MonoBehaviour {

	public float speed;

	public Vector3 direction;

	public KeyCode leftKey;

	public KeyCode rightkey;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetKey (rightkey)) {
		
			Vector3 step = direction.normalized * speed * Time.deltaTime;
			transform.Translate (step);
	
		}
		if (Input.GetKey (leftKey)) {

			Vector3 step = direction.normalized * speed * Time.deltaTime * -1;
			transform.Translate (step);
		}
	}
}
